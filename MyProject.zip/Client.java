public class Client {
	private String codeClient;
	private String rs;
	private String adresse;
	private String telephone;
}
